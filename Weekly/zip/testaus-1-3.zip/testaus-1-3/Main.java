/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.gpiste.Calculator;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author gessle
 */
public class Main {
    public static void main(String[] args) {
        Calculator c = new Calculator();
        ArrayList<Integer> vec = new ArrayList<>();
        int i = 1;
        String s ="";
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("***\nThis program calculates average of school grades (4-10). Input number, press enter. Zero (0) ends the input.");
        try {
            while (!s.contains("0")){
                System.out.println(i + ": ");
                s = reader.readLine();
                vec.add(Integer.parseInt(s));
                i++;
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println(c.divider(c.sum(vec), vec.size()));
        
        System.out.println("***");
        
    }
    
    
    
}

