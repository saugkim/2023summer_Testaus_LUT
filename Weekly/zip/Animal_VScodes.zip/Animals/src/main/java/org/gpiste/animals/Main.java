/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.animals;

import java.util.ArrayList;

/**
 *
 * @author gessle
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Animal> animals = new ArrayList<>();
        
        animals.add(new Doge("Bob", 4));
        animals.add(new Hedgehog("Karma", 2));
        animals.add(new Cat("Lisa", 14));
        animals.add(new Hedgehog("Sirius", 5));
        
        for (Animal a : animals) {
            System.out.println(a.shout());
        }
        
    }
    
}

