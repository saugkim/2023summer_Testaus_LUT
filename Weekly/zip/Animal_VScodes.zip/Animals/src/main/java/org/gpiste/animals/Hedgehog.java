/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.animals;

/**
 *
 * @author gessle
 */
public class Hedgehog extends Animal {
    
    public Hedgehog(String name, int age) {
        super(name, age);
    }

    @Override
    public String shout() {
        return this.getClass().getSimpleName() + ": Don't mind me, I spike you.";
    }
    
    
    
            
    
}
