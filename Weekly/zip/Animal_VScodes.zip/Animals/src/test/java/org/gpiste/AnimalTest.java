package org.gpiste;

import static org.junit.Assert.assertTrue;

import org.gpiste.animals.Cat;
import org.junit.Ignore;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AnimalTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }

    @Test
    public void catTest() {
        Cat c =  new Cat("Misse", 6);

        //assertEquals(expected, actual);
        assertTrue( true );
    }
}
