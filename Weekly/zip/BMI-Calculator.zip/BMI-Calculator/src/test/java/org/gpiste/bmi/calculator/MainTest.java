/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.bmi.calculator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author gessle
 */
public class MainTest {
    
    public MainTest() {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

   
    
    @org.junit.jupiter.api.Test
    public void testBMICalc() {
        BMICalc bmi = new BMICalc();
        assertEquals(24.7, bmi.getBMIdbouble(80, 1.8));

    }
    
    public void testBMICalc2() {
        BMICalc bmi = new BMICalc();
        assertEquals("Very severely obese", bmi.getBMImessage(160, 1.8));
    }
    
    
    
    
}
