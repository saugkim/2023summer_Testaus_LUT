/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.bmi.calculator;

/**
 *
 * @author gessle
 */
public class BMICalc {
    private int mass, height;

    public BMICalc() {
    }
    
    
    
    double getBMIdbouble(int mass, double height) {
        if (mass < 0)
            return -1;
        else if (height < 0)
            return -1;
        
        double bmi = (double) Math.round(mass / (height * height) * 10) / 10;
        return bmi;
    
    }
    
    String getBMImessage(int mass, double height) {
        String s = "";
        double bmi = this.getBMIdbouble(mass, height);
        
        if (bmi < 18.5) {
            s = "Underweight";
        }
        else if (bmi < 25) {
            s = "Normal weight";
        }
        else if (bmi < 30) {
            s = "Overweight";
        }
        else if (bmi < 35) {
            s = "Moderately obese";
        }     
        else if (bmi < 40) {
            s = "Severely obese";
        }     
        else if (bmi > 40) {
            s = "Very severely obese";
        }             
        
        return s;   
    
    }
    
    
    
}
