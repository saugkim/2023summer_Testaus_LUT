/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.stub;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author gessle
 */
public class StudentRegisterTest {
    
    public StudentRegisterTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    @Test
    public void testGetAverageGrade() {
        StudentRegister sr = new StudentRegister();
        assertEquals(3.5, sr.getAverageGrade("123"));
        assertEquals(2.1, sr.getAverageGrade("666"));
    }

    @Test
    public void testGetCourseName() {
        StudentRegister sr = new StudentRegister();
        assertEquals("Fundamentals of software testing", sr.getCourseName("CT60A4160"));
        assertEquals("Help 4 newbies", sr.getCourseName("CT60N00B"));
    }
    
    
    
    
}
