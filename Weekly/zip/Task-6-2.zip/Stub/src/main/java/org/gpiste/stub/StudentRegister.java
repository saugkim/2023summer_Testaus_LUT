/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.stub;

import java.util.ArrayList;

/**
 *
 * @author gessle
 */
public class StudentRegister {
    private DatabaseStub db;
    
    public StudentRegister() {
        db = new DatabaseStub();
    }
    
    public double getAverageGrade(String id) {
        ArrayList<Integer> grades = db.getGrades(id);
        int sum = 0;
        for (int i : grades) {
            sum += i;
        }
              
        return (double) sum / (double) grades.size();
    }
    
    public String getCourseName(String id) {
        return db.getCourseName(id);
    }
}
