/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.docking;

/**
 *
 * @author gessle
 */
public class Astronaut {
    private String name;

    public Astronaut(String name) {
        this.name = name;
        System.out.println("Astronaut created.");
    }

    public String getName() {
        return name;
    }
    
    
}
