/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.docking;

/**
 *
 * @author gessle
 */
public class SpaceStation {
    private Astronaut astronaut;
    private Spacecraft spacecraft;

    public SpaceStation() {
        System.out.println("Spacestation created.");
    }

    public Astronaut getAstronaut() {
        return astronaut;
    }

    public void setAstronaut(Astronaut astronaut) {
        this.astronaut = astronaut;
    }

    public Spacecraft undock() {
        if (spacecraft.getPilot() == null)
        {
            System.out.println("Undocking failed.");
            return null;
        }
        Spacecraft s = this.spacecraft;
        this.spacecraft = null;
        System.out.println("Spacecraft undocking with " + s.getPilot().getName() + " piloting it.");
        return s;
    }

    public void dock(Spacecraft spacecraft) {
        this.spacecraft = spacecraft;
        this.astronaut = spacecraft.getPilot();
    }
    

    
    
    
    
}
