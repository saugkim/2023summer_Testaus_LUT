/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gpiste.docking;

/**
 *
 * @author gessle
 */
public class Spacecraft {
    private Astronaut pilot;

    public Spacecraft() {
        System.out.println("Spacecraft created.");
    }

    public Astronaut getPilot() {
        return pilot;
    }
    public boolean removePilot() {
        this.pilot = null;
        return true;
    }

    public void setPilot(Astronaut pilot) {
        this.pilot = pilot;
    }
    
    
    
}
