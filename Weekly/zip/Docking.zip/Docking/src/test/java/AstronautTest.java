import static org.junit.Assert.assertEquals;

import org.gpiste.docking.Astronaut;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;


public class AstronautTest {
    private Astronaut astronaut;

    @Before
    public void init() {
        astronaut = new Astronaut("Mike");
    }

    @Test
    public void getPowerTest() {
        String expected = "Mike";
        String actual = astronaut.getName();
        assertEquals(expected, actual);
    }
}
